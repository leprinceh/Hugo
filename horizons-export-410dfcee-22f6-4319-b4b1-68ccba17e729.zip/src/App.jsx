
    import React from 'react';
    import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
    import LanguageSelectionPage from '@/pages/LanguageSelectionPage';
    import ChatPage from '@/pages/ChatPage';
    import { Toaster } from '@/components/ui/toaster';
    import { useState, useEffect } from 'react';

    function App() {
      const [selectedLanguage, setSelectedLanguage] = useState(() => {
        return localStorage.getItem('selectedLanguage') || '';
      });

      useEffect(() => {
        if (selectedLanguage) {
          localStorage.setItem('selectedLanguage', selectedLanguage);
        } else {
          localStorage.removeItem('selectedLanguage');
        }
      }, [selectedLanguage]);

      return (
        <Router>
          <div className="min-h-screen flex flex-col">
            <Routes>
              <Route
                path="/"
                element={
                  selectedLanguage ? (
                    <Navigate to="/chat" replace />
                  ) : (
                    <LanguageSelectionPage onLanguageSelect={setSelectedLanguage} />
                  )
                }
              />
              <Route
                path="/chat"
                element={
                  selectedLanguage ? (
                    <ChatPage
                      language={selectedLanguage}
                      onChangeLanguage={() => setSelectedLanguage('')}
                    />
                  ) : (
                    <Navigate to="/" replace />
                  )
                }
              />
            </Routes>
          </div>
          <Toaster />
        </Router>
      );
    }

    export default App;
  