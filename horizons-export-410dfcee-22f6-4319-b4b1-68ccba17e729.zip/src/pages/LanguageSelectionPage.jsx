
    import React from 'react';
    import { useState } from 'react';
    import { useNavigate } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import {
      Select,
      SelectContent,
      SelectItem,
      SelectTrigger,
      SelectValue,
    } from "@/components/ui/select";
    import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
    import { Label } from "@/components/ui/label";
    import { Globe } from 'lucide-react';
    import { useToast } from '@/components/ui/use-toast';


    const languages = [
      { value: 'fr', label: 'Français 🇫🇷' },
      { value: 'en', label: 'English 🇬🇧' },
      { value: 'es', label: 'Español 🇪🇸' },
      { value: 'de', label: 'Deutsch 🇩🇪' },
      { value: 'pt', label: 'Português 🇵🇹' },
      { value: 'it', label: 'Italiano 🇮🇹' },
    ];

    function LanguageSelectionPage({ onLanguageSelect }) {
      const [selectedLang, setSelectedLang] = useState('');
      const navigate = useNavigate();
      const { toast } = useToast();

      const handleSelect = () => {
        if (!selectedLang) {
           toast({
            title: "Erreur",
            description: "Veuillez sélectionner une langue.",
            variant: "destructive",
          });
          return;
        }
        onLanguageSelect(selectedLang);
        toast({
           title: "Succès!",
           description: `Langue définie sur ${languages.find(l => l.value === selectedLang)?.label}. Recherche d'un partenaire...`,
        });
        navigate('/chat');
      };

      return (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col items-center justify-center min-h-screen p-4"
        >
           <Card className="w-full max-w-md glass-card shadow-lg">
             <CardHeader className="text-center">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: 'spring', stiffness: 150 }}
                  className="mx-auto mb-4"
                >
                  <Globe className="w-16 h-16 text-primary" />
                </motion.div>
               <CardTitle className="text-3xl font-bold text-primary-foreground">Bienvenue sur Chatchat !</CardTitle>
               <CardDescription className="text-muted-foreground text-lg">Choisissez votre langue pour commencer.</CardDescription>
             </CardHeader>
             <CardContent className="space-y-6">
               <div className="space-y-2">
                 <Label htmlFor="language-select" className="text-primary-foreground">Votre langue</Label>
                 <Select onValueChange={setSelectedLang} value={selectedLang}>
                   <SelectTrigger id="language-select" className="w-full bg-background/80 text-foreground">
                     <SelectValue placeholder="Sélectionnez une langue..." />
                   </SelectTrigger>
                   <SelectContent>
                     {languages.map((lang) => (
                       <SelectItem key={lang.value} value={lang.value}>
                         {lang.label}
                       </SelectItem>
                     ))}
                   </SelectContent>
                 </Select>
               </div>
               <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button onClick={handleSelect} className="w-full text-lg py-6 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-semibold shadow-md transition-all duration-300 ease-in-out transform hover:-translate-y-1">
                  Trouver un partenaire
                </Button>
              </motion.div>
             </CardContent>
           </Card>
        </motion.div>
      );
    }

    export default LanguageSelectionPage;
  