
    import React, { useState, useEffect, useRef, useCallback } from 'react';
    import { motion, AnimatePresence } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
    import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
    import {
      AlertDialog,
      AlertDialogAction,
      AlertDialogCancel,
      AlertDialogContent,
      AlertDialogDescription,
      AlertDialogFooter,
      AlertDialogHeader,
      AlertDialogTitle,
      AlertDialogTrigger,
    } from "@/components/ui/alert-dialog";
    import { useToast } from '@/components/ui/use-toast';
    import { Send, UserMinus, LogOut, Globe } from 'lucide-react';

    // Mock function to simulate finding a partner
    const findPartner = (language) => {
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve({ id: Date.now(), name: `Utilisateur ${language.toUpperCase()}-${Math.floor(Math.random() * 1000)}`, lang: language });
        }, 1500); // Simulate network delay
      });
    };

    function ChatPage({ language, onChangeLanguage }) {
      const [messages, setMessages] = useState([]);
      const [inputValue, setInputValue] = useState('');
      const [partner, setPartner] = useState(null);
      const [isFindingPartner, setIsFindingPartner] = useState(true);
      const [isChangingPartner, setIsChangingPartner] = useState(false);
      const [isChangingLanguage, setIsChangingLanguage] = useState(false);
      const messagesEndRef = useRef(null);
      const { toast } = useToast();

      const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
      };

      const connectToNewPartner = useCallback(async () => {
        setIsFindingPartner(true);
        setPartner(null);
        setMessages([]); // Clear previous messages
        try {
          const newPartner = await findPartner(language);
          setPartner(newPartner);
          setMessages([{ type: 'system', text: `Vous êtes connecté avec ${newPartner.name}.` }]);
          toast({ title: "Connecté!", description: `Vous discutez maintenant avec ${newPartner.name}.` });
        } catch (error) {
          toast({ title: "Erreur", description: "Impossible de trouver un partenaire. Veuillez réessayer.", variant: "destructive" });
        } finally {
          setIsFindingPartner(false);
        }
      }, [language, toast]);


      useEffect(() => {
        connectToNewPartner();
      }, [connectToNewPartner]); // Connect on initial load and when language changes externally (though handled differently here)


      useEffect(() => {
        scrollToBottom();
      }, [messages]);

      const handleSendMessage = () => {
        if (inputValue.trim() === '' || !partner || isFindingPartner || isChangingPartner || isChangingLanguage) return;

        const newMessage = { type: 'user', text: inputValue };
        setMessages((prev) => [...prev, newMessage]);
        setInputValue('');

        // Simulate partner response
        setTimeout(() => {
          const partnerResponse = { type: 'partner', text: `Réponse de ${partner.name}: "${inputValue}"? Intéressant!` };
          setMessages((prev) => [...prev, partnerResponse]);
        }, 1000 + Math.random() * 1000);
      };

      const handleInputChange = (e) => {
        setInputValue(e.target.value);
      };

      const handleKeyPress = (e) => {
        if (e.key === 'Enter') {
          handleSendMessage();
        }
      };

      const handleChangePartner = async () => {
        setIsChangingPartner(true);
        toast({ title: "Recherche...", description: "Recherche d'un nouveau partenaire..." });
        await connectToNewPartner();
        setIsChangingPartner(false);
      };

      const handleChangeLanguageConfirm = () => {
        setIsChangingLanguage(true);
        toast({ title: "Déconnexion", description: "Retour à la sélection de la langue." });
        // Simulate "deleting" conversation from server by just resetting state
        setMessages([]);
        setPartner(null);
        localStorage.removeItem('selectedLanguage'); // Clear stored language
        onChangeLanguage(); // Trigger navigation back to language selection in App.jsx
        // No need to set setIsChangingLanguage(false) as the component will unmount
      };

       const getInitials = (name) => {
        if (!name) return '?';
        const parts = name.split(' ');
        if (parts.length > 1) {
            return parts[0][0] + parts[parts.length - 1][0];
        }
        return name.substring(0, 2);
       };


      return (
        <div className="flex flex-col h-screen p-4 max-w-3xl mx-auto w-full">
          <Card className="flex flex-col flex-grow glass-card shadow-xl overflow-hidden">
             <CardHeader className="flex flex-row items-center justify-between p-4 border-b border-white/20">
               <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center space-x-3">
                 {partner ? (
                   <>
                     <Avatar>
                       <AvatarFallback className="bg-primary text-primary-foreground">{getInitials(partner.name)}</AvatarFallback>
                     </Avatar>
                     <CardTitle className="text-xl font-semibold text-primary-foreground">{partner.name}</CardTitle>
                   </>
                 ) : (
                   <CardTitle className="text-xl font-semibold text-primary-foreground">
                     {isFindingPartner || isChangingPartner ? 'Recherche...' : 'Déconnecté'}
                    </CardTitle>
                 )}
               </motion.div>
               <div className="flex space-x-2">
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                       <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
                           <Button variant="ghost" size="icon" disabled={isFindingPartner || isChangingPartner || isChangingLanguage} className="text-primary-foreground hover:bg-white/20">
                             <UserMinus className="h-5 w-5" />
                             <span className="sr-only">Changer de partenaire</span>
                           </Button>
                       </motion.div>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Changer de partenaire ?</AlertDialogTitle>
                        <AlertDialogDescription>
                          Êtes-vous sûr de vouloir mettre fin à cette conversation et en commencer une nouvelle ? L'historique actuel sera perdu.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Annuler</AlertDialogCancel>
                        <AlertDialogAction onClick={handleChangePartner}>Confirmer</AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>

                  <AlertDialog>
                     <AlertDialogTrigger asChild>
                       <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
                           <Button variant="ghost" size="icon" disabled={isFindingPartner || isChangingPartner || isChangingLanguage} className="text-primary-foreground hover:bg-white/20">
                             <Globe className="h-5 w-5" />
                              <span className="sr-only">Changer de langue/pays</span>
                           </Button>
                        </motion.div>
                     </AlertDialogTrigger>
                     <AlertDialogContent>
                       <AlertDialogHeader>
                         <AlertDialogTitle>Changer de langue/pays ?</AlertDialogTitle>
                         <AlertDialogDescription>
                           Cela mettra fin à la conversation actuelle et vous ramènera à l'écran de sélection de la langue. L'historique sera perdu. Continuer ?
                         </AlertDialogDescription>
                       </AlertDialogHeader>
                       <AlertDialogFooter>
                         <AlertDialogCancel>Annuler</AlertDialogCancel>
                         <AlertDialogAction onClick={handleChangeLanguageConfirm}>Confirmer</AlertDialogAction>
                       </AlertDialogFooter>
                     </AlertDialogContent>
                   </AlertDialog>

               </div>
             </CardHeader>

             <CardContent className="flex-grow overflow-y-auto p-4 space-y-4 bg-background/50">
               <AnimatePresence>
                 {isFindingPartner && (
                    <motion.div
                      key="loading"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="text-center text-muted-foreground italic p-4"
                    >
                     Recherche d'un partenaire parlant {language}...
                   </motion.div>
                 )}
                {messages.map((msg, index) => (
                   <motion.div
                     key={index}
                     initial={{ opacity: 0, y: 10 }}
                     animate={{ opacity: 1, y: 0 }}
                     transition={{ duration: 0.3 }}
                     className={`flex ${msg.type === 'user' ? 'justify-end' : msg.type === 'partner' ? 'justify-start' : 'justify-center'}`}
                   >
                     {msg.type === 'system' ? (
                        <div className="text-center text-xs text-muted-foreground italic px-4 py-1 rounded-full bg-secondary">
                           {msg.text}
                         </div>
                     ) : (
                       <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg shadow ${
                         msg.type === 'user' ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white' : 'bg-secondary text-secondary-foreground'
                       }`}>
                         {msg.text}
                       </div>
                     )}
                   </motion.div>
                 ))}
               </AnimatePresence>
               <div ref={messagesEndRef} />
             </CardContent>

             <CardFooter className="p-4 border-t border-white/20 bg-background/80">
               <div className="flex w-full items-center space-x-2">
                 <Input
                   type="text"
                   placeholder={partner ? "Tapez votre message..." : "Connectez-vous pour chatter"}
                   value={inputValue}
                   onChange={handleInputChange}
                   onKeyPress={handleKeyPress}
                   disabled={!partner || isFindingPartner || isChangingPartner || isChangingLanguage}
                   className="flex-grow bg-background text-foreground border-primary/50 focus:border-primary focus:ring-primary"
                 />
                  <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
                     <Button
                       type="submit"
                       size="icon"
                       onClick={handleSendMessage}
                       disabled={!partner || isFindingPartner || isChangingPartner || isChangingLanguage || inputValue.trim() === ''}
                       className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-full"
                     >
                       <Send className="h-4 w-4" />
                       <span className="sr-only">Envoyer</span>
                     </Button>
                   </motion.div>
               </div>
             </CardFooter>
          </Card>
        </div>
      );
    }

    export default ChatPage;
  